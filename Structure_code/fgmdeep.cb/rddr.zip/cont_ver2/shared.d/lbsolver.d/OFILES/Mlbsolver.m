FILES = svaselld.o svasndld.o svasstif.o svpospro.o svprepro.o svreqest.o get_nd_neighbor.o sort_arr.o csvasstif.o  csvaselld.o get_master_neighbor.o csvasstif44.o  csvaselld44.o csvasstif11.o  csvaselld11.o csvasstif15.o  csvaselld15.o

FILES1  = svaselld.o svasstif.o svpospro.o svprepro.o svreqest.o svasndld.o get_nd_neighbor.o csvaselld.o csvasstif.o get_master_neighbor.o csvasstif44.o  csvaselld44.o csvasstif11.o  csvaselld11.o csvasstif15.o  csvaselld15.o

FILES2  = svaselld.o svasndld.o svasstif.o svpospro.o svprepro.o svreqest.o csvasstif.o csvasstif.o csvaselld.o csvasstif44.o  csvaselld44.o csvasstif11.o  csvaselld11.o csvasstif15.o  csvaselld15.o

FILES3  = svreqest.o

FILES4  = svreqest.o get_nd_neighbor.o get_master_neighbor.o

FILES5  =  get_nd_neighbor.o get_master_neighbor.o

FILES6  =  get_nd_neighbor.o get_master_neighbor.o

lbsolver.a  : $(FILES)
	ar r lbsolver.a $(FILES)

$(FILES1) : ../include.d/maxdim.f
$(FILES2) : ../include.d/sol_module.f
$(FILES3) : ../include.d/constr.f
$(FILES4) : ../include.d/global.f
$(FILES5) : ../include.d/eledef.f
$(FILES6) : ../include.d/coords.f

# .f.o : ;	fortran -g -c $*.f
# .f.o : ;      cft77 -e Isxz -o off $*.f
.f.o : ;     ifort -check all -c -O3 -u $*.f
.f.o : ;     ifort -c -O3 -u -parallel $*.f

