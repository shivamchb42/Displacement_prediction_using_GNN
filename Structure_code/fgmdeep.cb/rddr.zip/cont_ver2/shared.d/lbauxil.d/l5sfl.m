       subroutine l5sfm (xi,shape,der)

c+                                                                     +
c      subroutine l3sf (xi,shape,der)
c 
c      Function : Calculate  linear shape functions and
c                 their derivatives at gauss point
c
c      Description of variables :
c
c       Input variables :
c
c        . xi       = natural coordinate of current gauss point
c
c       Output variables :
c
c        . shape    = shape function at current gauss point
c        . der      = derivative of shape function w.r.t. natural coord.
c
c       Local variables :
c
c        . NONE
c     
c      Included common files :
c
c       . NONE
c     
c      Subroutine/Functions called :
c
c       . NONE
c
c      Written by : Creto Augusto Vidal & Hae-Sung Lee
c     
c      Date       : Fri Apr  5 09:44:50 CST 1991
c     
c      Version #  : 1
c     
c      Latest revision by :
c     
c      Date of revision   :
c     
c-                                                                     -

c      Argument variables

       real*8    xi,shape,der
       dimension shape(5),der(5)
 
c      ===============
c      Shape functions
c      ===============
 
       shape(1) =  -xi*(1.d0-xi)/2.d0
       shape(2) =   1.0d0-xi**2
       shape(3) =   xi*(1.d0+xi)/2.d0
       shape(4)=0.0d0
       shape(5)=0.0d0
 
c      ============================== 
c      Derivatives with respect to xi
c      ============================== 
 
       der(1) = xi-0.5d0
       der(2) = -2.0d0*xi
       der(3) = xi+0.5d0
       der(4)=0.0d0
       der(5)=0.0d0

       return

       end
 
