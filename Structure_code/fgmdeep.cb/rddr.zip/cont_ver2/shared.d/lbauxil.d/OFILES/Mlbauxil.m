FILES   = psichimaps.o Celtensraxi.o Celtensrsol.o bmatr4.o bmata4.o bmattra4.o bmatr9.o bmatb9.o bmata9.o bmattrb9.o bmattra9.o bmatr8.o bmats8.o bmattrs8.o bmatr6.o bmatr10.o bmatw6.o bmattrw6.o bmatb10.o bmatb18.o bmatrb9.o bmatrb10.o bmatrb18.o bmattrb10.o bmattrb18.o bmatr18.o bmatw18.o bmattrw18.o bmattrb27.o bmatr27.o bmatb27.o bmats27.o bmatrb27.o bmattrs27.o init.o intarray.o intgauss.o iunits.o numbdof.o opclg.o l2sf.o l3sf.o q4sf.o q8sf.o q9sf.o s8sf.o s27sf.o t3sf.o tr6sf.o t6sf.o t7sf.o w6sf.o w18sf.o t4sf.o t9sf.o t8sf.o t10sf.o tr10sf.o t18sf.o t27sf.o bmatp9.o bmatp4.o bmatp6.o bmatp3.o bmatrp9.o bmatrp4.o bmatrp6.o bmatrp3.o Celtensr2p.o gauss1d.o stiffmap.o map.o isarray.o clencurt.o bmatph9.o bmatrph9.o bmattrp9.o stiffmap44.o bmatph4.o bmatrph4.o bmattrph9.o  bmattrph4.o bmattrp4.o bmatp11.o stiffmap11.o q11sf.o l5sf.o l5sfm.o l5sfl.o bmatrp11.o bmatph11.o bmatrph11.o bmatp15.o bmatrp15.o l9sf.o l9sfl.o l9sfm.o stiffmap15.o q15sf.o bmatph15.o bmatrph15.o

FILES1  = numbdof.o smlist.o ndnormal.o

FILES2  = bmatr4.o bmata4.o bmattra4.o bmatr9.o bmatb9.o bmata9.o bmattrb9.o bmattra9.o bmatr8.o bmats8.o bmattrs8.o bmatr6.o bmatr10.o bmatw6.o bmattrw6.o bmatb10.o bmatb18.o bmatrb9.o bmatrb10.o bmatrb18.o bmattrb10.o bmattrb18.o bmatr18.o bmatw18.o bmattrw18.o bmattrb27.o bmatr27.o bmatb27.o bmats27.o bmatrb27.o bmattrs27.o bmatp9.o bmatp4.o bmatp6.o bmatp3.o bmatrp9.o bmatrp4.o bmatrp6.o bmatrp3.o smlist.o ndnormal.o normnorr.o cshapeder.o findmaster.o bmatph9.o bmatrph9.o bmattrp9.o bmatph4.o bmatrph4.o bmattrph9.o  bmattrph4.o bmattrp4.o bmatp11.o bmatrp11.o bmatp15.o bmatrp15.o bmatph11.o bmatph15.o bmatrph15.o

FILES3  = Celtensraxi.o Celtensrsol.o bmatr4.o bmata4.o bmattra4.o bmatr9.o bmatb9.o bmata9.o bmattrb9.o bmattra9.o bmatr8.o bmats8.o bmattrs8.o bmatr6.o bmatr10.o bmatw6.o bmattrw6.o bmatb10.o bmatb18.o bmatrb9.o bmatrb10.o bmatrb18.o bmattrb10.o bmattrb18.o bmatr18.o bmatw18.o bmattrw18.o bmattrb27.o bmatr27.o bmatb27.o bmats27.o bmatrb27.o bmattrs27.o intarray.o bmatp9.o bmatp4.o bmatp6.o bmatp3.o bmatrp9.o bmatrp4.o bmatrp6.o bmatrp3.o Centensr2p.o ndnormal.o findslave.o bmatph9.o bmatrph9.o bmattrp9.o bmatph4.o bmatrph4.o bmattrph9.o  bmattrph4.o bmattrp4.o bmatp11.o bmatrp11.o bmatp15.o bmatrp15.o bmatph11.o  bmatph15.o

FILES4  = intarray.o ndnormal.o findmaster.o findslave.o

FILES5  = init.o opclg.o iunits.o

FILES6  = init.o

FILES7  = bmatr4.o bmata4.o bmattra4.o bmatr9.o bmatb9.o bmata9.o bmattrb9.o bmattra9.o bmatr8.o bmats8.o bmattrs8.o bmatr6.o bmatr10.o bmatw6.o bmattrw6.o bmatb10.o bmatb18.o bmatrb9.o bmatrb10.o bmatrb18.o bmattrb10.o bmattrb18.o bmatr18.o bmatw18.o bmattrw18.o bmattrb27.o bmatr27.o bmatb27.o bmats27.o bmatrb27.o bmattrs27.o intarray.o numbdof.o bmatp9.o bmatp4.o bmatp6.o bmatp3.o bmatrp9.o bmatrp4.o bmatrp6.o bmatrp3.o findslave.o bmatph9.o bmatrph9.o bmattrp9.o bmatph4.o bmatrph4.o bmattrph9.o  bmattrph4.o bmattrp4.o bmatp11.o bmatrp11.o bmatp15.o bmatrp15.o Centensr2p.o bmatph11.o bmatph15.o bmatrph15.o

FILES8  = Celtensraxi.o Celtensrsol.o Centensr2p.o

FILES9 = bmatr4.o bmata4.o bmattra4.o bmatr9.o bmatb9.o bmata9.o bmattrb9.o bmattra9.o bmatr8.o bmats8.o bmattrs8.o bmatr6.o bmatr10.o bmatw6.o bmattrw6.o bmatb10.o bmatb18.o bmatrb9.o bmatrb10.o bmatrb18.o bmattrb10.o bmattrb18.o bmatr18.o bmatw18.o bmattrw18.o bmattrb27.o bmatr27.o bmatb27.o bmats27.o bmatrb27.o bmattrs27.o intarray.o numbdof.o bmatp9.o bmatp4.o bmatp6.o bmatp3.o bmatrp9.o bmatrp4.o bmatrp6.o bmatrp3.o smlist.o ndnormal.o normnorr.o cshapeder.o stiffmap.o findmaster.o findslave.o bmatph9.o bmatrph9.o bmattrp9.o stiffmap44.o bmatph4.o bmatrph4.o bmattrph9.o  bmattrph4.o bmattrp4.o bmatp11.o stiffmap11.o bmatrp11.o bmatp15.o bmatrp15.o stiffmap15.o bmatph15.o bmatrph15.o

FILES10 = intgauss.o findslave.o

FILES11 = intarray.o

FILES12 = stiffmap.o stiffmap44.o stiffmap11.o stiffmap15.o

lbauxil.a   : $(FILES)
	ar r lbauxil.a $(FILES)


$(FILES1)   : ../include.d/constr.f
$(FILES2)   : ../include.d/coords.f
$(FILES3)   : ../include.d/eledef.f
$(FILES4)   : ../include.d/fields.f
$(FILES5)   : ../include.d/filnam.f
$(FILES6)   : ../include.d/flags.f
$(FILES7)   : ../include.d/global.f
$(FILES8)   : ../include.d/materia.f
$(FILES9)  : ../include.d/maxdim.f
$(FILES10)  : ../include.d/quadrat.f
$(FILES11)  : ../include.d/sol_module.f
$(FILES12)  : ../include.d/shapecom.f

# .f.o : ; 	fortran  -g -c $*.f
# .f.o : ;      cft77    -e Isxz -o off $*.f
.f.o : ;     ifort -check all -c -O3 -u -parallel $*.f
.f.o : ;     ifort -mcmodel=large -c -O3 -u -parallel $*.f
