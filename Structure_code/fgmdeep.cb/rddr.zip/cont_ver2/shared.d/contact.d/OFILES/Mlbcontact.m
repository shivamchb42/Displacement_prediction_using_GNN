FILES  = stiffc99.o cee9stiff.o ces9stiff.o cem9stiff.o cme9stiff.o cmm9stiff.o cms9stiff.o c2es9stiff.o findmaster.o findslave.o smlist.o ndnormal.o normnorr.o cshapeder.o findgauss.o getcoords.o c99stiff.o ndlist.o findmastersl.o locateslave.o stiffc44.o cee4stiff.o ces4stiff.o cem4stiff.o cme4stiff.o cmm4stiff.o cms4stiff.o c2es4stiff.o findmaster4.o findslave44.o ndnormal44.o normnorr44.o cshapeder4.o getcoords44.o c44stiff.o ndlist44.o findmastersl44.o stiffc11.o cee11stiff.o ces11stiff.o cem11stiff.o cme11stiff.o cmm11stiff.o cms11stiff.o c2es11stiff.o findmaster11.o findslave11.o ndnormal11.o normnorr11.o cshapeder11.o getcoords11.o c11stiff.o ndlist11.o findmastersl11.o getcoords11m.o c11fstiff.o stiffc99pr.o cpr9stiff.o elsh9.o elsh11.o stiffc15.o cee15stiff.o ces15stiff.o cem15stiff.o cme15stiff.o cmm15stiff.o cms15stiff.o c2es15stiff.o findmaster15.o findslave15.o ndnormal15.o normnorr15.o cshapeder15.o getcoords15.o c15stiff.o ndlist15.o findmastersl15.o getcoords15m.o hybpr.o hybpr99.o c9cmat.o ndnormn0.o	


FILES1  = smlist.o ndnormal.o
FILES2  = stiffc99.o findguass.o ndnormal.o findslave.o findmaster.o c99stiff.o locateslave.o stiffc11.o ndnormal11.o findslave11.o findmaster11.o c11stiff.o

FILES3  = cee9stiff.o ces9stiff.o cem9stiff.o cme9stiff.o cmm9stiff.o cms9stiff.o c2es9stiff.o stiffc99.o findgauss.o  ndnormal.o findmaster.o findslave.o getcoords.o c99stiff.o cee11stiff.o ces11stiff.o cem11stiff.o cme11stiff.o cmm11stiff.o cms11stiff.o c2es11stiff.o stiffc11.o ndnormal11.o findmaster11.o findslave11.o getcoords11.o c11stiff.o hybpr.o hybpr99.o 

FILES4  = stiffc99.o findgauss.o  c99stiff.o locateslave.o hybpr.o hybpr99.o 

FILES5  = stiffc99.o cee9stiff.o  ces9stiff.o cem9stiff.o cme9stiff.o cmm9stiff.o cms9stiff.o c2es9stiff.o findgauss.o smlist.o ndnormal.o normnorr.o cshapeder.o  findmaster.o findslave.o chspaederp.o ceep9stiff.o getcoords.o c99stiff.o locateslave.o

FILES6  = stiffc99.o findgauss.o findslave.o stiffc99pr.o c99stiff.o

FILES7 =  cee9stiff.o ces9stiff.o cem9stiff.o cme9stiff.o cmm9stiff.o cms9stiff.o c2es9stiff.o smlist.o ndnormal.o normnorr.o cshapeder.o findmaster.o  stiffc99.o getcoords.o c99stiff.o

lbcont.a   : $(FILES)
	ar r lbcont.a $(FILES)

$(FILES1)   : ../include.d/constr.f
$(FILES2)  : ../include.d/eledef.f
$(FILES3)  : ../include.d/fields.f
$(FILES4)  : ../include.d/global.f
$(FILES5)  : ../include.d/maxdim.f
$(FILES6)  : ../include.d/quadrat.f
$(FILES7)  : ../include.d/coords.f
$(FILES8)  : ../include.d/shapecom.f
$(FILES9) : ../include.d/materia.f

# .f.o : ; 	fortran  -g -c $*.f
# .f.o : ;      cft77    -e Isxz -o off $*.f
#.f.o : ;     ifort -c -O3 -u -parallel $*.f
.f.o : ;     ifort  -check all -c  -O3 -u -parallel -I ../lbauxil.d $*.f
.f.o : ;     ifort -mcmodel=large  -c  -O3 -u -parallel -I ../lbauxil.d $*.f
