FILES  = findgauss.o 


FILES2  = findguass.o 

FILES3  = findgauss.o 

FILES4  = findgauss.o 

FILES5  = findgauss.o 

FILES6  =  findgauss.o 

lbcont9.a   : $(FILES)
	ar r lbcont9.a $(FILES)

$(FILES2)  : ../include.d/eledef.f
$(FILES3)  : ../include.d/fields.f
$(FILES4)  : ../include.d/global.f
$(FILES5)  : ../include.d/maxdim.f
$(FILES6)  : ../include.d/quadrat.f
$(FILES7)  : ../include.d/coords.f
$(FILES8)  : ../include.d/shapecom.f
$(FILES9) : ../include.d/materia.f

# .f.o : ; 	fortran  -g -c $*.f
# .f.o : ;      cft77    -e Isxz -o off $*.f
.f.o : ;     ifort -c -O3 -u -parallel $*.f
#.f.o : ;     ifort  -check all -c  -O3 -u -parallel -I ../lbauxil.d $*.f
£.f.o : ;     ifort -mcmodel=large  -c  -O3 -u -parallel -I ../lbauxil.d $*.f
