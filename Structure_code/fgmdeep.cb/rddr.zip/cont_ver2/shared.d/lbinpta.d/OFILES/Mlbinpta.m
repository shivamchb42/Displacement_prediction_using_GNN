FILES  = dspcstr.o eledefi.o matprop.o nodcoor.o nodload.o optdata.o facenode_fn.o sort_contfc.o create_fclim.o get_tnode.o check_inter.o get_facepair.o facenode_num.o create_fclim_x.o get_tboun.o create_fclim_pr.o intronode_9to11.o intronode_9to15.o

FILES1  = dspcstr.o create_fclim.o create_fclim_x.o create_fclim_pr.o

FILES2  = nodcoor.o nodcoor.o facenode_fn.o create_fclim.o facenode_num.o create_fclim_x.o create_fclim_pr.o intronode_9to11.o intronode_9to15.o

FILES3  = eledefi.o create_fclim.o facenode_fn.o get_tnode.o sort_contfc.o check_inter.o get_facepair.o facenode_num.o create_fclim_x.o get_tboun.o dspcstr.o create_fclim_pr.o intronode_9to11.o intronode_9to15.o

FILES4  = nodload.o nodload.o

FILES5  = dspcstr.o nodcoor.o facenode_fn.o facenode_num.o intronode_9to15.o

FILES6  = dspcstr.o eledefi.o matprop.o nodcoor.o nodload.o nodload.o create_fclim.o facenode_fn.o get_tnode.o check_inter.o get_facepair.o facenode_num.o create_fclim_x.o get_tboun.o create_fclim_pr.o intronode_9to15.o

FILES7  = nodload.o nodload.o

FILES8  = matprop.o

FILES9  = dspcstr.o eledefi.o matprop.o nodcoor.o nodload.o nodload.o create_fclim.o facenode_fn.o sort_contfc.o get_tnode.o check_inter.o get_facepair.o facenode_num.o create_fclim_x.o get_tboun.o create_fclim_pr.o intronode_9to11.o intronode_9to15.o

FILES10  = create_fclim_x.o

FILES11 = intronode_9to11.o intronode_9to15.o

lbinpta.a   : $(FILES)
	ar r lbinpta.a $(FILES)
 
$(FILES1)  : ../include.d/constr.f
$(FILES2)  : ../include.d/coords.f
$(FILES3)  : ../include.d/eledef.f
$(FILES4)  : ../include.d/filnam.f
$(FILES5)  : ../include.d/flags.f
$(FILES6)  : ../include.d/global.f
$(FILES7)  : ../include.d/loaddef.f
$(FILES8)  : ../include.d/materia.f
$(FILES9)  : ../include.d/maxdim.f
$(FILES10)  : ../include.d/fields.f
$(FILES11)  : ../include.d/shapecom.f
 
# .f.o : ;        fortran -g -c $*.f
# .f.o : ;	cft77 -e Isxz -o off $*.f
.f.o : ;     ifort -check all -c -O3 -u -parallel $*.f
.f.o : ;     ifort -mcmodel=large -c -O3 -u -parallel $*.f

