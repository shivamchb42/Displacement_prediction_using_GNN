FILES  = addvect.o cpvect.o dcopy.o dgbsv.o dgemm.o dgemv.o dger.o dgesv.o dlamch.o dlaswp.o dgbtrf.o dgbtrs.o dgbtf2.o dgetf2.o dgetrf.o dgetrs.o dscal.o dswap.o dsyr.o dsyrk.o dtrsm.o dtbsv.o dtrsv.o idamax.o ieeeck.o ilaenv.o lsame.o rdwrda.o rdwrtp.o scxvect.o subvect.o vecnorm.o xerbla.o zero.o zeroc.o zeroi.o zeror.o

lbutilit.a   : $(FILES)
	ar r lbutilit.a $(FILES)

# .f.o : ; 	fortran  -g -c $*.f
# .f.o : ;      cft77    -e Isxz -o off $*.f
.f.o : ;     ifort -c -O3 -u -parallel $*.f
