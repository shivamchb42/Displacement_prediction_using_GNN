FILES  = sslda40.o sslda90.o sslds80.o ssldw60.o ssldb100.o ssldb180.o ssldw180.o sslds270.o ssceldva44.o ssceldvtra44.o ssceldva99.o ssceldvtra99.o ssceldvs88.o ssceldvtrs88.o ssceldvs2727.o ssceldvtrs2727.o ssceldvw66.o ssceldvtrw66.o ssceldvb1011.o ssceldvw1818.o ssceldvtrb1011.o ssceldvtrw1818.o ssprldb4.o ssprldb9.o ssprldtrb4.o ssprldtrb9.o ssprldb6.o ssprldb68.o ssprldb10.o ssprldb18.o ssprldb1827.o ssprldtrb6.o ssprldtrb68.o ssprldtrb10.o ssprldtrb18.o ssprldtrb1827.o ssprldb8.o ssprldb27.o ssprldtrb8.o ssprldtrb27.o totldinc.o ssldp90.o ssldp40.o ssldp60.o ssldp30.o ssprldp9.o ssprldp6.o ssprldp4.o ssprldp3.o ssldp91.o ssldp110.o ssldp150.o

FILES1  = sslda40.o sslda90.o sslds80.o ssldw60.o ssldb100.o ssldb180.o ssldw180.o sslds270.o ssceldva44.o ssceldvtra44.o ssceldva99.o ssceldvtra99.o ssceldvs88.o ssceldvtrs88.o ssceldvs2727.o ssceldvtrs2727.o ssceldvw66.o ssceldvtrw66.o ssceldvb1011.o ssceldvw1818.o ssceldvtrb1011.o ssceldvtrw1818.o ssprldb4.o ssprldb9.o ssprldtrb4.o ssprldtrb9.o ssprldb6.o ssprldb68.o ssprldb10.o ssprldb18.o ssprldb1827.o ssprldtrb6.o ssprldtrb68.o ssprldtrb10.o ssprldtrb18.o ssprldtrb1827.o ssprldb8.o ssprldb27.o ssprldtrb8.o ssprldtrb27.o ssldp90.o ssldp40.o ssldp60.o ssldp30.o ssprldp9.o ssprldp6.o ssprldp4.o ssprldp3.o ssldp110.o ssldp150.o

FILES2  = sslda40.o sslda90.o sslds80.o ssldw60.o ssldb100.o ssldb180.o ssldw180.o sslds270.o ssceldva44.o ssceldvtra44.o ssceldva99.o ssceldvtra99.o ssceldvs88.o ssceldvtrs88.o ssceldvs2727.o ssceldvtrs2727.o ssceldvw66.o ssceldvtrw66.o ssceldvb1011.o ssceldvw1818.o ssceldvtrb1011.o ssceldvtrw1818.o ssprldb4.o ssprldb9.o ssprldtrb4.o ssprldtrb9.o ssprldb6.o ssprldb68.o ssprldb10.o ssprldb18.o ssprldb1827.o ssprldtrb6.o ssprldtrb68.o ssprldtrb10.o ssprldtrb18.o ssprldtrb1827.o ssprldb8.o ssprldb27.o ssprldtrb8.o ssprldtrb27.o ssldp90.o ssldp40.o ssldp60.o ssldp30.o ssprldp9.o ssprldp6.o ssprldp4.o ssprldp3.o ssldp110.o ssldp150.o

FILES3  = sslda40.o sslda90.o sslds80.o ssldw60.o ssldb100.o ssldb180.o ssldw180.o sslds270.o ssceldva44.o ssceldvtra44.o ssceldva99.o ssceldvtra99.o ssceldvs88.o ssceldvtrs88.o ssceldvs2727.o ssceldvtrs2727.o ssceldvw66.o ssceldvtrw66.o ssceldvb1011.o ssceldvw1818.o ssceldvtrb1011.o ssceldvtrw1818.o ssprldb4.o ssprldb9.o ssprldtrb4.o ssprldtrb9.o ssprldb6.o ssprldb68.o ssprldb10.o ssprldb18.o ssprldb1827.o ssprldtrb6.o ssprldtrb68.o ssprldtrb10.o ssprldtrb18.o ssprldtrb1827.o ssprldb8.o ssprldb27.o ssprldtrb8.o ssprldtrb27.o totldinc.o ssldp90.o ssldp40.o ssldp60.o ssldp30.o ssprldp9.o ssprldp6.o ssprldp4.o ssprldp3.o ssldp110.o ssldp150.o

FILES4  = totldinc.o

FILES5  = ssceldva44.o ssceldvtra44.o ssceldva99.o ssceldvtra99.o ssceldvs88.o ssceldvtrs88.o ssceldvs2727.o ssceldvtrs2727.o ssceldvw66.o ssceldvtrw66.o ssceldvb1011.o ssceldvw1818.o ssceldvtrb1011.o ssceldvtrw1818.o ssprldb4.o ssprldb9.o ssprldtrb4.o ssprldtrb9.o ssprldb6.o ssprldb68.o ssprldb10.o ssprldb18.o ssprldb1827.o ssprldtrb6.o ssprldtrb68.o ssprldtrb10.o ssprldtrb18.o ssprldtrb1827.o ssprldb8.o ssprldb27.o ssprldtrb8.o ssprldtrb27.o ssprldp9.o ssprldp6.o ssprldp4.o ssprldp3.o

FILES6  = ssldw60.o sslds80.o ssldb100.o ssldb180.o ssldw180.o sslds270.o sslda40.o sslda90.o ssprldb6.o ssprldb68.o ssprldb10.o ssprldb18.o ssprldb1827.o ssprldtrb6.o ssprldtrb68.o ssprldtrb10.o ssprldtrb18.o ssprldtrb1827.o ssprldb8.o ssprldb27.o ssprldtrb8.o ssprldtrb27.o ssprldb4.o ssprldb9.o ssprldtrb4.o ssprldtrb9.o ssceldva44.o ssceldvtra44.o ssceldva99.o ssceldvtra99.o ssceldvs88.o ssceldvtrs88.o ssceldvs2727.o ssceldvtrs2727.o ssceldvw66.o ssceldvtrw66.o ssceldvb1011.o ssceldvw1818.o ssceldvtrb1011.o ssceldvtrw1818.o ssldp90.o ssldp40.o ssldp60.o ssldp30.o ssprldp9.o ssprldp6.o ssprldp4.o ssprldp3.o ssldp110. ssldp150.oo

FILES7  = ssceldva44.o ssceldvtra44.o ssceldva99.o ssceldvtra99.o ssceldvs88.o ssceldvtrs88.o ssceldvs2727.o ssceldvtrs2727.o ssceldvw66.o ssceldvtrw66.o ssceldvb1011.o ssceldvw1818.o ssceldvtrb1011.o ssceldvtrw1818.o

lbloads.a   : $(FILES)
	ar r lbloads.a $(FILES)

$(FILES1) : ../include.d/coords.f
$(FILES2) : ../include.d/eledef.f
$(FILES3) : ../include.d/maxdim.f
$(FILES4) : ../include.d/sol_module.f
$(FILES5) : ../include.d/shapecom.f
$(FILES6) : ../include.d/fields.f
$(FILES7) : ../include.d/materia.f

# .f.o : ; 	fortran  -g -c $*.f
# .f.o : ;      cft77    -e Isxz -o off $*.f
.f.o : ;     ifort -check all -c -O3 -u -parallel $*.f
.f.o : ;     ifort -mcmodel=large -c -O3 -u -parallel $*.f



