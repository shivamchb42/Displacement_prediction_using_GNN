FILES  = elemstif.o hmscalc.o a4stfa.o a4stfatr.o b9stfa.o a9stfa.o b9stfatr.o a9stfatr.o s8stfa.o s8stfatr.o w6stfa.o w6stfatr.o b10stfa.o b18stfa.o b10stfatr.o b18stfatr.o w18stfa.o w18stfatr.o b27stfa.o b27stfatr.o s27stfa.o s27stfatr.o stiffa44.o stifftra44.o stiffb99.o stiffa99.o stifftrb99.o stifftra99.o stiffs88.o stifftrs88.o stiffw66.o stifftrw66.o stiffb1011.o stiffb1818.o stifftrb1011.o stifftrb1818.o stiffw1818.o stifftrw1818.o stiffb2727.o stifftrb2727.o stiffs2727.o stifftrs2727.o p9stfa.o p4stfa.o p6stfa.o p3stfa.o stiffp99.o stiffp44.o stiffp66.o stiffp33.o  stiffph99.o ph9stfa.o p9stfatr.o stifftrp99.o stiffph44.o ph4stfa.o stifftrph99.o ph9stfatr.o p4stfatr.o stifftrp44.o stifftrph44.o ph4stfatr.o p11stfa.o stiffp11.o ph11stfa.o stiffph11.o p15stfa.o stiffp15.o ph15stfa.o stiffph15.o

FILES1  = elemstif.o

FILES2  = hmscalc.o elemstif.o a4stfa.o a4stfatr.o b9stfa.o a9stfa.o b9stfatr.o a9stfatr.o s8stfa.o s8stfatr.o w6stfa.o w6stfatr.o b10stfa.o b18stfa.o b10stfatr.o b18stfatr.o w18stfa.o w18stfatr.o b27stfa.o b27stfatr.o s27stfa.o s27stfatr.o p9stfa.o p4stfa.o p6stfa.o p3stfa.o ph9stfa.o p9stfatr.o stiffph44.o ph4stfa.o p4stfatr.o stifftrph44.o ph4stfatr.o p4stfa.o p11stfa.o ph11stfa1.o ph11stfa2.o stiffph11.o stiffph15.o 

FILES3  = elemstif.o s8stfa.o s8stfatr.o w6stfa.o w6stfatr.o b27stfa.o b27stfatr.o s27stfa.o s27stfatr.o b10stfa.o b18stfa.o b10stfatr.o b18stfatr.o w18stfa.o w18stfatr.o a4stfa.o a4stfatr.o b9stfa.o a9stfa.o b9stfatr.o a9stfatr.o p9stfa.o p4stfa.o p6stfa.o p3stfa.o ph9stfa.o p9stfatr.o stiffph44.o ph4stfa.o ph4stfatr.o ph9stfatr.o p4stfatr.o p4stfa.o p11stfa.o ph11stfa1.o ph11stfa2.o 

FILES4  = hmscalc.o elemstif.o a4stfa.o a4stfatr.o b9stfa.o a9stfa.o b9stfatr.o a9stfatr.o s8stfa.o s8stfatr.o w6stfa.o w6stfatr.o b10stfa.o b18stfa.o b10stfatr.o b18stfatr.o w18stfa.o w18stfatr.o b27stfa.o b27stfatr.o s27stfa.o s27stfatr.o p9stfa.o p4stfa.o p6stfa.o p3stfa.o ph9stfa.o p9stfatr.o stiffph44.o ph4stfa.o ph9stfatr.o ph4stfatr.o p4stfa.o p11stfa.o ph11stfa1.o ph11stfa2.o 

FILES5  = hmscalc.o elemstif.o a4stfa.o a4stfatr.o b9stfa.o a9stfa.o b9stfatr.o a9stfatr.o s8stfa.o s8stfatr.o b27stfa.o b27stfatr.o s27stfa.o s27stfatr.o stiffa44.o stifftra44.o stiffb99.o stiffa99.o stifftrb99.o stifftra99.o stiffs88.o stifftrs88.o stiffw66.o stifftrw66.o stiffb1011.o stiffb1818.o stifftrb1011.o stifftrb1818.o stiffw1818.o stifftrw1818.o stiffb2727.o stifftrb2727.o stiffs2727.o stifftrs2727.o p9stfa.o p4stfa.o p6stfa.o p3stfa.o stiffp99.o stiffp44.o stiffp66.o stiffp33.o stiffph99.o ph9stfa.o p9stfatr.o stifftrp99.o stiffph44.o ph4stfa.o stifftrph99.o ph9stfatr.o p4stfatr.o stifftrp44.o stifftrph44.o ph4stfatr.o p11stfa.o stiffp11.o ph11stfa1.o ph11stfa2.o stiffph11.o p15stfa.o stiffp15.o ph11stfa.o stiffph11.o

FILES6  = stiffa44.o stifftra44.o stiffb99.o stiffa99.o stifftrb99.o stifftra99.o stiffs88.o stifftrs88.o stiffw66.o stifftrw66.o stiffb1011.o stiffb1818.o stifftrb1011.o stifftrb1818.o stiffw1818.o stifftrw1818.o stiffb2727.o stifftrb2727.o stiffs2727.o stifftrs2727.o stiffp99.o stiffp44.o stiffp66.o stiffp33.o stiffph99.o stifftrp99.o stiffph44.o ph4stfa.o stifftrp44.o stifftrph44.o stiffp11.o p15stfa.o stiffp15.o stiffph15.o

FILES7 = hmscalc.o 

FILES8 = elemstif.o stiffa44.o stifftra44.o stiffb99.o stiffa99.o stifftrb99.o stifftra99.o stiffs88.o stifftrs88.o stiffw66.o stifftrw66.o stiffb1011.o stiffb1818.o stifftrb1011.o stifftrb1818.o stiffw1818.o stifftrw1818.o stiffb2727.o stifftrb2727.o stiffs2727.o stifftrs2727.o stiffp99.o stiffp44.o stiffp66.o stiffp33.o stiffph99.o stifftrp99.o stiffph44.o ph4stfa.o stifftrp44.o stifftrph44.o stiffp11.o p15stfa.o stiffp15.o stiffph15.o

FILES9= a4stfatr.o b9stfatr.o a9stfatr.o s8stfatr.o w6stfatr.o b10stfatr.o b18stfatr.o w18stfatr.o b27stfatr.o s27stfatr.o  p9stfatr.o p4stfatr.o ph9stfatr.o ph4stfatr.o ph11stfa1.o ph11stfa2.o ph15stfa.o 

lbstiff.a   : $(FILES)
	ar r lbstiff.a $(FILES)

$(FILES1)  : ../include.d/Cijkl_tensr.f
$(FILES2)  : ../include.d/eledef.f
$(FILES3)  : ../include.d/fields.f
$(FILES4)  : ../include.d/global.f
$(FILES5)  : ../include.d/maxdim.f
$(FILES6)  : ../include.d/quadrat.f
$(FILES7)  : ../include.d/coords.f
$(FILES8)  : ../include.d/shapecom.f
$(FILES9) : ../include.d/materia.f

# .f.o : ; 	fortran  -g -c $*.f
# .f.o : ;      cft77    -e Isxz -o off $*.f
#.f.o : ;     ifort -c -O3 -u -parallel $*.f
.f.o : ;     ifort  -check all -c  -O3 -u -parallel -I ../lbauxil.d $*.f
.f.o : ;     ifort  -mcmodel=large -c  -O3 -u -parallel -I ../lbauxil.d $*.f
