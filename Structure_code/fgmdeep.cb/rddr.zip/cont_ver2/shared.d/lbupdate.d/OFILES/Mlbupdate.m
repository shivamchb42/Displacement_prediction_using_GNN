FILES  = calcmom.o pressb44.o pressb99.o pressb88.o pressb66.o pressb1011.o pressb1818.o pressb2727.o upfilmom88.o upfilmom66.o upfilmom1011.o upfilmom1818.o upfilmom2727.o upfilmom44.o upfilmom99.o upmom88.o upmom66.o upmom1011.o upmom1818.o upmom2727.o upmom44.o upmom99.o update.o upepsprea4.o upepsa4.o upepsprea9.o upepsb9.o upepsa9.o upepspres8.o upepss8.o upepsprew6.o upepsw6.o upepsprew18.o upepsw18.o upepsb10.o upepsb18.o upepsb27.o upepspres27.o upepss27.o upfila4.o upfila44.o upfila9.o upfilb99.o upfila99.o upfils88.o upfilw6.o upfilw66.o upfilb1011.o upfilb1818.o upfilw18.o upfilw1818.o upfilb2727.o upfils8.o upfils27.o upfils2727.o uppress.o upsspeliso2d.o upsspelisoaxi.o upsspelaxi.o upsspeliso.o upsspelsol.o upepsp9.o upepsp4.o upepsp6.o upepsp3.o upfilp33.o upfilp66.o upfilp44.o upfilp99.o pressp99.o pressp44.o pressp66.o pressp33.o upfilph99.o upfilph9.o upepspres9.o upepsph9.o upsspel2d.o pressph99.o upfilph44.o upfilph4.o upepspres4.o upepsph4.o upfilp11.o upepsp11.o upfilph11.o upfilph111.o upepspres11.o upepsph11.o upfilp15.o upepsp15.o upfilph15.o upfilph1515.o upepspres15.o upepsph15.o pressp11.o 

FILES1  = calcmom.o pressb44.o pressb99.o pressb88.o pressb66.o pressb1011.o pressb1818.o pressb2727.o upfilmom88.o upfilmom66.o upfilmom1011.o upfilmom1818.o upfilmom2727.o upfilmom44.o upfilmom99.o upmom88.o upmom66.o upmom1011.o upmom1818.o upmom2727.o upmom44.o upmom99.o update.o upepsprea4.o upepsa4.o upepsprea9.o upepsb9.o upepsa9.o upepspres8.o upepss8.o upepsprew6.o upepsw6.o upepsprew18.o upepsw18.o upepspres27.o upepss27.o upfila4.o upfila44.o upfila9.o upfilb99.o upfila99.o upfils88.o upfilw6.o upfilw66.o upfilb1011.o upfilb1818.o upfilw18.o upfilw1818.o upfilb2727.o upfils8.o upfils27.o upfils2727.o uppress.o upfilp33.o upfilp66.o upfilp44.o upfilp99.o pressp99.o pressp44.o pressp66.o pressp33.o upfilph99.o upfilph9.o upepspres9.o upepsph9.o upsspel2d.o pressph99.o upfilph44.o upfilph4.o upepspres4.o upepsph4.o upfilp11.o upfilp15.o pressp11.o

FILES2  = calcmom.o pressb44.o pressb99.o pressb88.o pressb66.o pressb1011.o pressb1818.o pressb2727.o upfilmom88.o upfilmom66.o upfilmom1011.o upfilmom1818.o upfilmom2727.o upfilmom44.o upfilmom99.o upmom88.o upmom66.o upmom1011.o upmom1818.o upmom2727.o upmom44.o upmom99.o update.o upepsprea4.o upepsa4.o upepsprea9.o upepsb9.o upepsa9.o upepspres8.o upepss8.o upepsprew6.o upepsw6.o upepsprew18.o upepsw18.o upepsb10.o upepsb18.o upepsb27.o upepspres27.o upepss27.o upfila4.o upfila44.o upfila9.o upfilb99.o upfila99.o upfils88.o upfilw6.o upfilw66.o upfilb1011.o upfilb1818.o upfilw18.o upfilw1818.o upfilb2727.o upfils8.o upfils27.o upfils2727.o uppress.o upepsp9.o upepsp4.o upepsp6.o upepsp3.o upfilp33.o upfilp66.o upfilp44.o upfilp99.o pressp99.o pressp44.o pressp66.o pressp33.o upfilph99.o upfilph9.o upepspres9.o upepsph9.o upsspel2d.o pressph99.o upfilph44.o upfilph4.o upepspres4.o upepsph4.o upfilp11.o  upfilp15.o upepsp15.o pressp11.o

FILES3  = upfilmom88.o upfilmom66.o upfilmom1011.o upfilmom1818.o upfilmom2727.o upfilmom44.o upfilmom99.o upfila44.o upfilb99.o upfila99.o upfils88.o upfilw66.o upfilb1011.o upfilb1818.o upfilw1818.o upfilb2727.o upfils2727.o upfilp33.o upfilp66.o upfilp44.o upfilp99.o pressp99.o pressp44.o pressp66.o pressp33.o upfilph99.o pressph99.o upfilph44.o upfilph4.o upepspres4.o upepsph4.o upfilp11.o upfilp15.o pressp11.o

FILES4  = upmom88.o upmom66.o upmom1011.o upmom1818.o upmom2727.o upmom44.o upmom99.o upfila44.o upfilb99.o upfila99.o calcmom.o update.o upfils88.o upfilw66.o upfilb1011.o upfilb1818.o upfilw1818.o upfilb2727.o upfils2727.o upfilp33.o upfilp66.o upfilp44.o upfilp99.o upfilph99.o upsspel2d.o upfilph44.o upfilph4.o upepspres4.o upepsph4.o upfilp11.o upfilp15.o

FILES5  = assmblq.o

FILES6  = calcmom.o pressb44.o pressb99.o pressb88.o pressb66.o pressb1011.o pressb1818.o pressb2727.o upmom88.o upmom66.o upmom1011.o upmom1818.o upmom2727.o upmom44.o upmom99.o update.o upepsprea4.o upepsa4.o upepsprea9.o upepsb9.o upepsa9.o upepspres8.o upepss8.o upepsprew6.o upepsw6.o upepsprew18.o upepsw18.o upepspres27.o upepss27.o uppress.o upfila4.o upfila9.o upfilw6.o upfilw18.o upfils8.o upfils27.o pressp99.o pressp44.o pressp66.o pressp33.o upfilph9.o upepspres9.o upepsph9.o pressph99.o upfilph44.o upfilph4.o upepspres4.o upepsph4.o pressp11.o

FILES7 = calcmom.o pressb44.o pressb88.o pressb66.o pressb1011.o pressb1818.o pressb2727.o update.o uppress.o upfils8.o upfila4.o upfila9.o upfilw6.o upfilw18.o upfils8.o upfils27.o pressp99.o pressp44.o pressp66.o pressp33.o upfilph9.o pressph99.o upfilph44.o upfilph4.o upepspres4.o upepsph4.o

FILES8 = update.o

FILES9 = upmom88.o upmom66.o upmom1011.o upmom1818.o upmom2727.o upmom44.o upmom99.o pressp99.o pressp44.o pressp66.o pressp33.o pressph99.o upfilph44.o upfilph4.o upepspres4.o upepsph4.o pressp11.o

FILES10 = pressp99.o pressp44.o pressp66.o pressp33.o upsspel2d.o pressph99.o pressp11.o
lbupdate.a   : $(FILES)
	ar r lbupdate.a $(FILES)

$(FILES1) : ../include.d/eledef.f
$(FILES2) : ../include.d/maxdim.f
$(FILES3) : ../include.d/quadrat.f
$(FILES4) : ../include.d/shapecom.f
$(FILES5) : ../include.d/sol_module.f
$(FILES6) : ../include.d/global.f
$(FILES7) : ../include.d/fields.f
$(FILES8) : ../include.d/Cijkl_tensr.f
$(FILES9): ../include.d/coords.f
$(FILES10): ../include.d/materia.f

# .f.o : ; 	fortran  -g -c $*.f
# .f.o : ;      cft77    -e Isxz -o off $*.f
.f.o : ;     ifort -c -O3 -u -parallel -I ../lbauxil.d $*.f
