FILES = complnce0.o ctrldata.o elvol.o inputb.o iusrtpb.o main.o plstrnener.o sencrp.o strnener0.o vola44.o vola99.o vols88.o volw66.o volt1011.o volw1818.o vols2727.o print.o contread.o outread.o restart.o prpost.o findface.o printfinpt.o

FILES1 = ctrldata.o

FILES2 = main.o sencrp.o print.o prpost.o

FILES3 = complnce0.o elvol.o iusrtpb.o main.o plstrnener.o strnener0.o vols88.o volw66.o volt1011.o volw1818.o vols2727.o contread.o print.o outread.o prpost.o

FILES4 = complnce0.o main.o sencrp.o vols88.o volw66.o volt1011.o vols2727.o volw1818.o vola44.o vola99.o print.o  prpost.o

FILES5 = iusrtpb.o

FILES6 = inputb.o iusrtpb.o main.o sencrp.o print.o prpost.o

FILES7 = complnce0.o ctrldata.o elvol.o main.o plstrnener.o sencrp.o strnener0.o print.o contread.o outread.o prpost.o

FILES8 = complnce0.o main.o sencrp.o print.o

FILES9 = main.o plstrnener.o strnener0.o

FILES10 = complnce0.o ctrldata.o elvol.o main.o plstrnener.o sencrp.o strnener0.o vola44.o vola99.o vols88.o volw66.o volt1011.o volw1818.o vols2727.o print.o contread.o outread.o prpost.o

FILES11 = main.o plstrnener.o strnener0.o vola44.o vola99.o vols88.o volw66.o volt1011.o volw1818.o vols2727.o

FILES12 =  ctrldata.o

FILES13 = complnce0.o elvol.o iusrtpb.o main.o plstrnener.o sencrp.o strnener0.o vola44.o vola99.o vols88.o volw66.o volt1011.o volw1818.o vols2727.o print.o contread.o

FILES14 = complnce0.o sencrp.o print.o contread.o

FILES15 = sencrp.o print.o

creep.a : $(FILES)
	ar r creep.a $(FILES)

$(FILES1)  : shared.d/include.d/cmodel.f
$(FILES2)  : shared.d/include.d/constr.f
$(FILES3)  : shared.d/include.d/eledef.f
$(FILES4)  : shared.d/include.d/fields.f
$(FILES5)  : shared.d/include.d/filnam.f
$(FILES6)  : shared.d/include.d/flags.f
$(FILES7) : shared.d/include.d/global.f
$(FILES8) : shared.d/include.d/loaddef.f
$(FILES9) : shared.d/include.d/materia.f
$(FILES10) : shared.d/include.d/maxdim.f
$(FILES11) : shared.d/include.d/quadrat.f
$(FILES12) : shared.d/include.d/senfile.f
$(FILES13) : shared.d/include.d/shapecom.f
$(FILES14) : shared.d/include.d/sol_module.f
$(FILES15) : shared.d/include.d/coords.f

.f.o : ;     ifort -c -O3 -u -parallel $*.f

