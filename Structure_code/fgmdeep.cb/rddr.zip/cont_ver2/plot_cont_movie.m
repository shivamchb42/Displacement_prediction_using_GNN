%plot_cont(filename,ls,ci,it,bd,fldx,fldy,ch);
lmorder=2;
ls=1;                 % load step
ci=1;                 % contact iteration
it=1;                 % Iteration
fldx=10;         % x -axis  1-node ,2-x  3-y ,4-ux, 5-uy 6-lam 7-sigmx 8-sigy 9 - sigxy 10 - x+ux  11 y+uy  
fldy=11;        % y -axis
ch='--r*';
%hold on

figure(70)
set(gcf, 'Position', get(0,'Screensize'));
set(gca,'FontSize',20,'FontWeight','bold');

nframes = 150;
Frames = moviein(nframes);
frameno = 0;

%for ls = [1:5:100,102:2:140]
    
frameno = frameno + 1;
figure(70)
ch='--r*';
bd=1;                 % body slave or master
plot_cont('disp',lmorder,ls,ci,it,bd,fldx,fldy,ch)
bd=2;
ch='--g*';
hold on
plot_cont('disp',lmorder,ls,ci,it,bd,fldx,fldy,ch)
axis([0  250    40   160]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% fldx=2;         % x -axis  1-node ,2-x  3-y ,4-ux, 5-uy 6-lam 7-sigmx 8-sigy
% fldy=6;        % y -axis
% ch='-b*';
% hold on
% figure(70)
% plot_cont('results/disp.hertz.coarse.ph9.3e7',lmorder,ls,ci,it,bd,fldx,fldy,ch)
% bd=1;
% ch='-m^';
% hold on
% figure(70)
% plot_cont('results/disp.hertz.coarse.p9.3e7',lmorder,ls,ci,it,bd,fldx,fldy,ch)



xlabel('X (m)','fontsize',20);
ylabel('Y (m)','fontsize',22);
title('For catiliver beam: slave 30 element, master:20 element');
%legend({'hybrid stress ', 'coventional stress', 'hybrid pressure','convential pressure '},'FontSize',25,'FontWeight','bold','Location','northwest')
legend({'slave body' 'master body'},'FontSize',25,'FontWeight','bold','Location','northwest')
set(gcf,'PaperPositionMode','auto')
Frames(:,frameno) = getframe(gcf);
hold off;
%end

%movie(Frames,1);
% Creating AVI file:
% ------------------
movie2avi(Frames,'semi.avi','fps',4);
%print('results/pressureit5_30_20','-depsc','-r800')
%f1=figure(70);
%saveas(f1,'results/pressureit5_25_20_hyb','fig')
%savefig('pressureit5_30_20.fig')