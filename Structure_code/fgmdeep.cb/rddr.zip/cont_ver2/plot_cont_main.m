%plot_cont(filename,ls,ci,it,bd,fldx,fldy,ch);
lmorder=2;
ls=10;               % load step
ci=20;                 % contact iteration
it=11;                 % Iteration
fldx=10;         % x -axis  1-node ,2-x  3-y ,4-ux, 5-uy 6-lam 7-sigmx 8-sigy 9 - sigxy 10 - x+ux  11 y+uy  
fldy=11;        % y -axis
ch='--r*';
hold on

figure(2)
set(gcf, 'Position', get(0,'Screensize'));
set(gca,'FontSize',20,'FontWeight','bold');

nframes = 240;
%Frames = moviein(nframes);
frameno = 0;
 [slvdata,masdata,nlamarr,nmasarr]=plot_cont_read('disp');
%for ls = [1:5:140]
frameno = frameno + 1;
figure(2)
ch='-k*';
bd=1;                 % body slave or master
ndisp = 1;            % 1 if you want to print node number 0 otherwise
plot_cont(slvdata,masdata,lmorder,ls,ci,it,bd,fldx,fldy,ch,0,nlamarr,nmasarr)
bd=2;
ch='-k*';
hold on
plot_cont(slvdata,masdata,lmorder,ls,ci,it,bd,fldx,fldy,ch,0,nlamarr,nmasarr)
%axis([-30  20   -5   20]);
grid on;
ch='--b^';
hold on
fldy=7;        % y -axis
figure(3)
hold on
bd=2;
plot_cont(slvdata,masdata,lmorder,ls,ci,it,bd,fldx,fldy,ch,1,nlamarr,nmasarr)
ch='--g*';
% fldy=7
% bd=2;
% plot_cont(slvdata,masdata,lmorder,ls,ci,it,bd,fldx,fldy,ch,0,nlamarr,nmasarr)
% hold on
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ls=210;
% fldy=11;    
% [slvdata,masdata,nlamarr,nmasarr]=plot_cont_read('disp.er.ph9.30.t1.in2');
% %for ls = [1:5:140]
% frameno = frameno + 1;
% figure(2)
% ch='--b';
% bd=1;                 % body slave or master
% ndisp = 1;            % 1 if you want to print node number 0 otherwise
% plot_cont(slvdata,masdata,lmorder,ls,ci,it,bd,fldx,fldy,ch,0,nlamarr,nmasarr)
% bd=2;
% ch='--b';
% hold on
% plot_cont(slvdata,masdata,lmorder,ls,ci,it,bd,fldx,fldy,ch,0,nlamarr,nmasarr)
% %axis([-30  20   -5   20]);
% grid on;
% fldy=6;        % y -axis
% hold on
% figure(3)
% bd=1;
% plot_cont(slvdata,masdata,lmorder,ls,ci,it,bd,fldx,fldy,ch,0,nlamarr,nmasarr)
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ls=140;
% fldy=11;    
% [slvdata,masdata,nlamarr,nmasarr]=plot_cont_read('disp.er.ph9.30.t1');
% %for ls = [1:5:140]
% frameno = frameno + 1;
% figure(2)
% ch='--g';
% bd=1;                 % body slave or master
% ndisp = 1;            % 1 if you want to print node number 0 otherwise
% plot_cont1(slvdata,masdata,lmorder,ls,ci,it,bd,fldx,fldy,ch,0,nlamarr,nmasarr)
% bd=2;
% ch='--g';
% hold on
% plot_cont1(slvdata,masdata,lmorder,ls,ci,it,bd,fldx,fldy,ch,0,nlamarr,nmasarr)
% %axis([-30  20   -5   20]);
% grid on;
% fldy=6;        % y -axis
% hold on
% figure(3)
% bd=1;
% plot_cont1(slvdata,masdata,lmorder,ls,ci,it,bd,fldx,fldy,ch,0,nlamarr,nmasarr)




% fldx=2;         % x -axis  1-node ,2-x  3-y ,4-ux, 5-uy 6-lam 7-sigmx 8-sigy
% fldy=6;        % y -axis
% ch='-b*';
% hold on
% figure(70)
% plot_cont('results/disp.hertz.coarse.ph9.3e7',lmorder,ls,ci,it,bd,fldx,fldy,ch)
% bd=1;
% ch='-m^';
% hold on
% figure(70)
% plot_cont('results/disp.hertz.coarse.p9.3e7',lmorder,ls,ci,it,bd,fldx,fldy,ch)



xlabel('X (m)','fontsize',20);
ylabel('Y (m)','fontsize',22);
title(['ls = ',num2str(ls)]);
%print('arc_defo','-depsc','-r800')
%legend({'hybrid stress ', 'coventional stress', 'hybrid pressure','convential pressure '},'FontSize',25,'FontWeight','bold','Location','northwest')
legend({'slave body' 'master body'},'FontSize',25,'FontWeight','bold','Location','northwest')
set(gcf,'PaperPositionMode','auto')
Frames(:,frameno) = getframe(gcf);
hold off;
%end

%movie(Frames,1);
% Creating AVI file:
% ------------------
%movie2avi(Frames,'twocirc.avi','fps',4);
%print('results/pressureit5_30_20','-depsc','-r800')
%f1=figure(70);
%saveas(f1,'results/pressureit5_25_20_hyb','fig')
%savefig('pressureit5_30_20.fig')