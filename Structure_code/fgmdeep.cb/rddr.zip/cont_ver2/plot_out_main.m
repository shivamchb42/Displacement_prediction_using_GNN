%plot_cont(filename,ls,ci,it,bd,fldx,fldy,ch);
lmorder=2;
ls=1;                 % load step
bd=1;                 % body slave or master
ci=1;                 % contact iteration
it=15;                 % Iteration
fldx=2;               % x -axis  1-node ,2-x  3-y ,4-ux, 5-uy 6-lam 7-sigmax 8-sigma_y 9- sigma_xy 10: defx 11 : defy
fldy=9;               % y -axis
ch='--g*';
hold on
figure(60)
plot_out('out.umiddile.singlebeam.p9.20',lmorder,ls,ci,it,bd,fldx,fldy,ch)
