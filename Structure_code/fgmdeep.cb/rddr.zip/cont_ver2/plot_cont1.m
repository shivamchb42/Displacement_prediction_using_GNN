function []=plot_cont1(slvdata,masdata,lmorder,ls,ci,it,bd,fldx,fldy,ch,ndisp,nlamarr,nmasarr)
mx_iter=50;
mx_contiter=5;
mx_loadstep=400;
index=(ls-1)*mx_contiter*mx_iter+(ci-1)*mx_iter+it;


if (bd == 1)
    while(slvdata(index,1,1) ==0)
        index=index-1;
    end
    [xaxis, arr]=sort(slvdata(index,:,2));
    yaxis=slvdata(index,arr,fldy);
    if (fldy ==6 && lmorder==1)
        [xaxis, arr]=sort(slvdata(index,1:2:nlamarr,fldx));
        yaxis=slvdata(index,arr,fldy);
    end
    xaxis=(slvdata(index,arr,fldx));
    plot(xaxis-125,yaxis,ch);
    if (ndisp == 1)
        for i=1:nlamarr
            x(1)=slvdata(index,i,10);
            x(2)=slvdata(index,i,11);
            text('Position',x,'String',num2str(slvdata(index,i,1)),'FontSize',8,'Color','k');
        end
        
    end
    
    
end
if (bd == 2)
    while(slvdata(index,1,1) ==0)
        index=index-1;
    end
    [xaxis, arr]=sort(masdata(index,:,2));
    yaxis=masdata(index,arr,fldy);
    if (fldy ==6&& lmorder==1)
        [xaxis, arr]=sort(masdata(index,1:2:nlamarr,fldx));
        yaxis=masdata(index,arr,fldy);
    end
    xaxis=(masdata(index,arr,fldx));
    plot(xaxis-125,yaxis,ch);
    if (ndisp == 1)
        for i=1:nmasarr
            x1(1)=masdata(index,i,10);
            x1(2)=masdata(index,i,11)+1;
            text('Position',x1,'String',num2str(masdata(index,i,1)),'FontSize',8,'Color','k');
        end
        
    end
    
end
end
