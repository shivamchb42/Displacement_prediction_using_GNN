function []=plot_out(filename,lmorder,ls,ci,it,bd,fldx,fldy,ch)
fid = fopen(filename,'r');
mx_iter=40;
mx_contiter=10;
mx_loadstep=100;

 for i=1:4

fgetl(fid);
%lsize = size(line);
 end
 
 fscanf(fid,'%s',1)
 noutarr = fscanf(fid,'%d',1);
 
 outdata=zeros(mx_iter*mx_contiter*mx_loadstep,noutarr,11);
 fscanf(fid,'%s',1)

%fscanf(fid,'%s',1);
while~feof(fid)
   
     factor = fscanf(fid,'%e',1);
     fscanf(fid,'%s',1);
     itercont= fscanf(fid,'%d',1);
     fscanf(fid,'%s',1);
     loadstep = fscanf(fid,'%d',1);
     fscanf(fid,'%s',1);
     iter = fscanf(fid,'%d',1);
     index=(loadstep-1)*mx_contiter*mx_iter+(itercont-1)*mx_iter+iter;
     fgetl(fid);
     fgetl(fid);
        for i=1:noutarr
     
            outdata(index,i,1)=fscanf(fid,'%d',1);
          
            outdata(index,i,2:9)=fscanf(fid,'%e',8);
        end
           outdata(index,:,10)= outdata(index,:,2)+ outdata(index,:,4);
            outdata(index,:,11)= outdata(index,:,3)+ outdata(index,:,5);
     fgetl(fid);
     fgetl(fid);
        
            fscanf(fid,'%s',1);
end
    index=(ls-1)*mx_contiter*mx_iter+(ci-1)*mx_iter+it;
    
  

    while(outdata(index,1,1) ==0)
        index=index-1;
    end
    [xaxis, arr]=sort(outdata(index,:,fldx));
    yaxis=outdata(index,arr,fldy);
       if (fldy ==6 && lmorder==1)
 [xaxis, arr]=sort(outdata(index,1:2:nlamarr,fldx));
    yaxis=outdata(index,arr,fldy);
       end

  plot(xaxis,yaxis,ch);
    

  
end
