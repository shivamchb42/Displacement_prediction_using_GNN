function [prmat,load,expo,iter,x] = read_conv(filename,ls)
fid = fopen(filename,'r');

% fscanf(fid,'%s',2);
% nslv = fscanf(fid,'%d\n',1);
% fgetl(fid)
prmat = zeros(ls,25);
load = zeros(ls,25);
expo=zeros(ls,25);
for i = 1:ls
    fscanf(fid,'%s',3);
nslv = fscanf(fid,'%d\n',1);
    prval = [];
    prval1 = [];
    prval2 = [];
    x = [];
    for j = 1:nslv
       
        x = [x,fscanf(fid,'%e',1)];
        
      %  fscanf(fid,'%e',1);
        
        prval = [prval,fscanf(fid,'%e',1)];
        prval1 = [prval1,fscanf(fid,'%e',1)];
        prval2 = [prval2,fscanf(fid,'%e\n',1)];
        %fscanf(fid,'%e',1);
        %fscanf(fid,'%e\n',1);
       
    end
  
    prmat(i,1:nslv) = prval;
    load(i,1:nslv) = prval1;
    expo(i,1:nslv)=prval2;
    iter(i)=nslv;
    %fgetl(fid);
end