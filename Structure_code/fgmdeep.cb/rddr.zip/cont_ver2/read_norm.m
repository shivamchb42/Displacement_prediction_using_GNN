function [prmat,x] = read_norm(filename,ls)
fid = fopen(filename,'r');

fscanf(fid,'%s',2);
nslv = fscanf(fid,'%d\n',1);
fgetl(fid)
prmat = zeros(ls,nslv);
for i = 1:ls
    
    prval = [];
    x = [];
    for j = 1:nslv
       
        x = [x,fscanf(fid,'%e',1)];
        
      %  fscanf(fid,'%e',1);
        
        prval = [prval,fscanf(fid,'%e\n',1)];
        %fscanf(fid,'%e',1);
        %fscanf(fid,'%e',1);
       
    end
  
    prmat(i,:) = prval;
    fgetl(fid);
end