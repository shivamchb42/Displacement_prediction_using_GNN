function [slvdata,masdata,nlamarr,nmasarr]=plot_cont_read(filename)
fid = fopen(filename,'r');
mx_iter=40;
mx_contiter=21;
mx_loadstep=200;

 for i=1:9

fgetl(fid);
%lsize = size(line);
 end
 
 fscanf(fid,'%s',1);
 nlamarr = fscanf(fid,'%d',1);
 
 slvdata=zeros(mx_iter*mx_contiter*mx_loadstep,nlamarr,9);
 fscanf(fid,'%s',1);
 nmasarr = fscanf(fid,'%d',1);
 masdata=zeros(mx_iter*mx_contiter*mx_loadstep,nmasarr,9);
fscanf(fid,'%s',1);
while~feof(fid)
   
     factor = fscanf(fid,'%e',1);
     fscanf(fid,'%s',1);
     itercont= fscanf(fid,'%d',1);
     fscanf(fid,'%s',1);
     loadstep = fscanf(fid,'%d',1);
     fscanf(fid,'%s',1);
     iter = fscanf(fid,'%d',1);
     index=(loadstep-1)*mx_contiter*mx_iter+(itercont-1)*mx_iter+iter;
     fgetl(fid);
     fgetl(fid);
        for i=1:nlamarr
     
            slvdata(index,i,1)=fscanf(fid,'%d',1);
            slvdata(index,i,2:9)=fscanf(fid,'%e',8);
             
        end
           slvdata(index,:,10)= slvdata(index,:,2)+ slvdata(index,:,4);
            slvdata(index,:,11)= slvdata(index,:,3)+ slvdata(index,:,5);
             
     fgetl(fid);
     fgetl(fid);
        for i=1:nmasarr
     
            masdata(index,i,1)=fscanf(fid,'%d',1);
            masdata(index,i,2:9)=fscanf(fid,'%e',8);
        end
             masdata(index,:,10)= masdata(index,:,2)+ masdata(index,:,4);
            masdata(index,:,11)= masdata(index,:,3)+ masdata(index,:,5);
            fscanf(fid,'%s',1);
end