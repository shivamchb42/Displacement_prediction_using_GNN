clear all
clc
filename1 = 'conv';
% filename5 = 'sring_p9_90_80';

[pr1,load,expo,iter,x1] = read_conv(filename1,80);
figure(1)
plot(pr1(20,:),'-k*')
hold on
plot(pr1(40,:),'-b*')
hold on
plot(pr1(60,:),'-g*')
hold on
plot(pr1(80,:),'-r*')
figure(2)

plot(expo(20,(3:iter(20))))
hold on
plot(expo(40,(3:iter(40))))
hold on
plot(expo(60,(3:iter(60))))
hold on
plot(expo(80,(3:iter(80))))
figure(3)

%plot(load(20,(3:iter(20))))
%hold on
%plot(load(40,(3:iter(40))))
%hold on
%plot(load(60,(3:iter(60))))
%hold on
plot(load(80,(1:iter(80))))
set(gcf, 'Position', get(0,'Screensize'));
set(gca,'FontSize',20,'FontWeight','bold');
xlabel('Iteration number','fontsize',22);
%set(gcf,'Norm of normalised residual force','auto')
xlim([-85 -60]);
%xaxis([0,40]);
%legend('p9 50ele','p11 20ele','p9 20ele','p11 20ele','location','southeast');
ylabel('Norm of normalised residual force','fontsize',22);
grid on;
print('conv','-depsc','-r800')
