#!/bin/bash
cp norm  patch_res/norm_ph9_32
cp shape patch_res/shape_ph9_32 
cp disp patch_res/disp_ph9_32 


