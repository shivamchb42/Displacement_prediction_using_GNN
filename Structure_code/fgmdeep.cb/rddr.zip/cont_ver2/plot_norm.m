clear all
clc
filename1 = 'norm_p9_8';
filename2 = 'norm_p9_32';
 filename3 = 'norm_p9_128';
filename4 = 'norm_p9_512';
% filename5 = 'sring_p9_90_80';

[pr1,x1] = read_norm(filename1,1);
err1=1-pr1;
max_err(1)=max(abs(err1));

[pr2,x2] = read_norm(filename2,1);
err2=1-pr2;
max_err(2)=max(abs(err2));

[pr3,x3] = read_norm(filename3,1);
err3=1-pr3;
max_err(3)=max(abs(err3));

[pr4,x4] = read_norm(filename4,1);
err4=1-pr4;
max_err(4)=max(abs(err4));

  


